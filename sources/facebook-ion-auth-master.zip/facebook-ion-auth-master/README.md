facebook-ion-auth
=================

facebook login working with ion_auth (codeigniter)

